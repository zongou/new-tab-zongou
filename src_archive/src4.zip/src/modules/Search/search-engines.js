export default [{
  name: 'Google',
  link: 'https://www.google.com/search?q=%s'
}, {
  name: '百度',
  link: 'https://www.baidu.com/s?wd=%s'
}, {
  name: '搜狗',
  link: 'https://www.sogou.com/web?query=%s'
}, {
  name: 'Bing',
  link: 'https://www.bing.com/search?q=%s'
}]
